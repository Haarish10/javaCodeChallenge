package mainmod;

import dao.OrderProcessor;
import dao.User;
import dao.*;
import entity.*;
import util.DBUtil;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@SuppressWarnings("unused")
public class MainModule {

    public static void main(String[] args) {
        try {

            Connection conn = DBUtil.getDBConn();
            System.out.println("Database connected successfully.");

            OrderProcessor orderProcessor = new OrderProcessor();

            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("1. Create User");
                System.out.println("2. Create Product");
                System.out.println("3. Create Order");
                System.out.println("4. Cancel Order");
                System.out.println("5. Get All Products");
                System.out.println("6. Get Order by User");
                System.out.println("7. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                if (choice == 1) {
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    System.out.print("Enter role (Admin/User): ");
                    String role = scanner.nextLine();
                    User user = new User();
                    user.setUsername(username);
                    user.setPassword(password);
                    user.setRole(role);
                    orderProcessor.createUser(user);
                    System.out.println("User created successfully.");
                } else if (choice == 2) {
                    System.out.print("Enter product name: ");
                    String productName = scanner.nextLine();
                    System.out.print("Enter description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    System.out.print("Enter quantity in stock: ");
                    int quantityInStock = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter type (Electronics/Clothing): ");
                    String type = scanner.nextLine();
                    Product product;
                    if (type.equalsIgnoreCase("Electronics")) {
                        product = new Electronics(quantityInStock, type, type, price, quantityInStock, type, type,
                                quantityInStock);
                        System.out.print("Enter brand: ");
                        ((Electronics) product).setBrand(scanner.nextLine());
                        System.out.print("Enter warranty period: ");
                        ((Electronics) product).setWarrantyPeriod(scanner.nextInt());
                        scanner.nextLine();
                    } else if (type.equalsIgnoreCase("Clothing")) {
                        product = new Clothing();
                        System.out.print("Enter size: ");
                        ((Clothing) product).setSize(scanner.nextLine());
                        System.out.print("Enter color: ");
                        ((Clothing) product).setColor(scanner.nextLine());
                    } else {
                        System.out.println("Invalid product type.");
                        continue;
                    }
                    product.setProductName(productName);
                    product.setDescription(description);
                    product.setPrice(price);
                    product.setQuantityInStock(quantityInStock);
                    product.setType(type);
                    orderProcessor.createProduct(new User(), product);
                    System.out.println("Product created successfully.");
                } else if (choice == 3) {
                    System.out.print("Enter user ID: ");
                    int userId = scanner.nextInt();
                    scanner.nextLine();
                    List<Product> products = new ArrayList<>();
                    while (true) {
                        System.out.print("Enter product ID to add to order (or -1 to finish): ");
                        int productId = scanner.nextInt();
                        if (productId == -1) {
                            break;
                        }
                        Product orderedProduct = new Product();
                        orderedProduct.setProductId(productId);
                        products.add(orderedProduct);
                    }
                    User orderUser = new User();
                    orderUser.setUserId(userId);
                    orderProcessor.createOrder(orderUser, products);
                    System.out.println("Order created successfully.");
                } else if (choice == 4) {
                    System.out.print("Enter user ID: ");
                    int cancelUserId = scanner.nextInt();
                    System.out.print("Enter order ID: ");
                    int orderId = scanner.nextInt();
                    orderProcessor.cancelOrder(cancelUserId, orderId);
                    System.out.println("Order canceled successfully.");
                } else if (choice == 5) {
                    List<Product> allProducts = orderProcessor.getAllProducts();
                    for (Product p : allProducts) {
                        System.out.println(p);
                    }
                } else if (choice == 6) {
                    System.out.print("Enter user ID: ");
                    int orderUserId = scanner.nextInt();
                    User orderUserDetails = new User();
                    orderUserDetails.setUserId(orderUserId);
                    List<Product> userOrders = orderProcessor.getOrderByUser(orderUserDetails);
                    for (Product p : userOrders) {
                        System.out.println(p);
                    }
                } else if (choice == 7) {
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                } else {
                    System.out.println("Invalid choice. Try again.");
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
