package util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
    public static Connection getDBConn() throws Exception {
        String url = "jdbc:mysql://localhost:3306/OrderManagementSystem";
        String username = "root";
        String password = "Haarishraj&10";

        return DriverManager.getConnection(url, username, password);
    }
}
