package dao;

import entity.*;
import entity.Product;
import util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

@SuppressWarnings("unused")
public class OrderProcessor implements IOrderManagementRepository {
    @Override
    public void createOrder(User user, List<Product> products) throws Exception {
        Connection conn = DBUtil.getDBConn();
        String orderQuery = "INSERT INTO `Order` (userId) VALUES (?)";
        PreparedStatement orderStmt = conn.prepareStatement(orderQuery, PreparedStatement.RETURN_GENERATED_KEYS);
        orderStmt.setInt(1, user.getUserId());
        orderStmt.executeUpdate();
        ResultSet rs = orderStmt.getGeneratedKeys();
        if (rs.next()) {
            int orderId = rs.getInt(1);
            for (Product product : products) {
                String orderProductQuery = "INSERT INTO OrderProduct (orderId, productId) VALUES (?, ?)";
                PreparedStatement orderProductStmt = conn.prepareStatement(orderProductQuery);
                orderProductStmt.setInt(1, orderId);
                orderProductStmt.setInt(2, product.getProductId());
                orderProductStmt.executeUpdate();
            }
        }

    }

    @Override
    public void cancelOrder(int userId, int orderId) throws Exception {
        Connection conn = DBUtil.getDBConn();
        String deleteOrderProductQuery = "DELETE FROM OrderProduct WHERE orderId = ?";
        PreparedStatement deleteOrderProductStmt = conn.prepareStatement(deleteOrderProductQuery);
        deleteOrderProductStmt.setInt(1, orderId);
        deleteOrderProductStmt.executeUpdate();

        String deleteOrderQuery = "DELETE FROM `Order` WHERE orderId = ? AND userId = ?";
        PreparedStatement deleteOrderStmt = conn.prepareStatement(deleteOrderQuery);
        deleteOrderStmt.setInt(1, orderId);
        deleteOrderStmt.setInt(2, userId);
        deleteOrderStmt.executeUpdate();
    }

    @Override
    public void createProduct(User user, Product product) throws Exception {
        Connection conn = DBUtil.getDBConn();
        String productQuery = "INSERT INTO Product (productName, description, price, quantityInStock, type) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement productStmt = conn.prepareStatement(productQuery);
        productStmt.setString(1, product.getProductName());
        productStmt.setString(2, product.getDescription());
        productStmt.setDouble(3, product.getPrice());
        productStmt.setInt(4, product.getQuantityInStock());
        productStmt.setString(5, product.getType());
        productStmt.executeUpdate();
    }

    @Override
    public void createUser(User user) throws Exception {
        Connection conn = DBUtil.getDBConn();
        String userQuery = "INSERT INTO User (username, password, role) VALUES (?, ?, ?)";
        PreparedStatement userStmt = conn.prepareStatement(userQuery);
        userStmt.setString(1, user.getUsername());
        userStmt.setString(2, user.getPassword());
        userStmt.setString(3, user.getRole());
        userStmt.executeUpdate();
    }

    @Override
    public List<Product> getAllProducts() throws Exception {
        Connection conn = DBUtil.getDBConn();
        String query = "SELECT * FROM Product";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();
        List<Product> products = new ArrayList<>();
        while (rs.next()) {
            Product product = new Product();
            product.setProductId(rs.getInt("productId"));
            product.setProductName(rs.getString("productName"));
            product.setDescription(rs.getString("description"));
            product.setPrice(rs.getDouble("price"));
            product.setQuantityInStock(rs.getInt("quantityInStock"));
            product.setType(rs.getString("type"));
            products.add(product);
        }
        return products;
    }

    @Override
    public List<Product> getOrderByUser(User user) throws Exception {
        Connection conn = DBUtil.getDBConn();
        String query = "SELECT p.* FROM Product p JOIN OrderProduct op ON p.productId = op.productId JOIN `Order` o ON op.orderId = o.orderId WHERE o.userId = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, user.getUserId());
        ResultSet rs = stmt.executeQuery();
        List<Product> products = new ArrayList<>();
        while (rs.next()) {
            Product product = new Product();
            product.setProductId(rs.getInt("productId"));
            product.setProductName(rs.getString("productName"));
            product.setDescription(rs.getString("description"));
            product.setPrice(rs.getDouble("price"));
            product.setQuantityInStock(rs.getInt("quantityInStock"));
            product.setType(rs.getString("type"));
            products.add(product);
        }
        return products;
    }
}
